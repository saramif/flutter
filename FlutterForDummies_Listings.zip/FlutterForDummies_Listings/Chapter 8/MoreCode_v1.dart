import 'ReuseMe.dart';

extension MyExtension on ReuseMe {
  void displayNicely() {
    print('The value of x is $x.');
  }
}