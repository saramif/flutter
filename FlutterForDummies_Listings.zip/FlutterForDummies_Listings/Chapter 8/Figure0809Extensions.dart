// Figure0809Extensions.dart

import 'package:flutter/material.dart';

import 'Figure0809Main.dart';

extension MoreMovieTitlePage on MovieTitlePageState {
  Future<Widget> goToDetailPage() async {
    isFavorite = await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DetailPage(),
            settings: RouteSettings(
              arguments: isFavorite,
            ),
          ),
        ) ??
        isFavorite;
    setState(() {});
  }

  Widget buildTitlePageCore() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Being John Malkovich',
              textScaleFactor: 1.5,
            ),
            Visibility(
              visible: isFavorite,
              child: Icon(Icons.favorite),
            ),
          ],
        ),
        SizedBox(height: 16.0),
        RaisedButton.icon(
          icon: Icon(Icons.arrow_forward),
          label: Text('Details'),
          onPressed: goToDetailPage,
        ),
      ],
    );
  }
}

Widget buildDetailPageCore(context) {
  final overview = '(From themoviedb.com) One day at work, unsuccessful '
      'puppeteer Craig finds a portal into the head of actor John '
      'Malkovich. The portal soon becomes a passion for anybody who '
      'enters its mad and controlling world of overtaking another human '
      'body.';
  final isFavorite = ModalRoute.of(context).settings.arguments;
  return Column(
    crossAxisAlignment: CrossAxisAlignment.center,
    children: <Widget>[
      Text(
        overview,
      ),
      SizedBox(height: 16.0),
      RaisedButton(
        child: Text(
          isFavorite ? 'Unfavorite this' : 'Make it a Favorite!',
        ),
        onPressed: () {
          Navigator.pop(context, !isFavorite);
        },
      ),
    ],
  );
}
