// Another good version of MoreCode.dart

import 'ReuseMe.dart';

extension MyExtension on ReuseMe {
  void displayNicely() {
    print('   * $x *  ');
    print('  ** $x ** ');
    print(' *** $x ***');
    print('**** $x ****');
  }
}