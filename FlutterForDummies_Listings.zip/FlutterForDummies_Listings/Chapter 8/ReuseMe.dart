import 'MoreCode.dart';

class ReuseMe {
  int x = 229;
}

main() => ReuseMe().displayNicely();
