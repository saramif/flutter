// Figure0809Main.dart

import 'package:flutter/material.dart';

import 'Figure0809Extensions.dart';

void main() => runApp(App08Main());

class App08Main extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MovieTitlePage(),
    );
  }
}

class MovieTitlePage extends StatefulWidget {
  @override
  MovieTitlePageState createState() => MovieTitlePageState();
}

class MovieTitlePageState extends State<MovieTitlePage> {
  bool isFavorite = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Movie Title',
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: buildTitlePageCore(),
        ),
      ),
    );
  }
}

class DetailPage extends StatelessWidget {
  Future<bool> _onPop(BuildContext context) {
    return showDialog(
          context: context,
          child: AlertDialog(
            title: Text("The back button doesn't work"),
            content: Text('Sorry about that, Chief.'),
            actions: <Widget>[
              new FlatButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: Text('OK'),
              ),
            ],
          ),
        ) ??
        false;
  }

  Future<bool> _onPop2() async {
    Future.value(false);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => _onPop(context),
      child: Scaffold(
          appBar: AppBar(
            title: Text(
              "Details",
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Center(
              child: buildDetailPageCore(context),
            ),
          )),
    );
  }
}
